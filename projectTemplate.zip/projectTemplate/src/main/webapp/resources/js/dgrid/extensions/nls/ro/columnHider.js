//>>built
define("dgrid/extensions/nls/ro/columnHider",{popupTriggerLabel:"Afișarea sau ascunderea coloanelor",popupLabel:"Afișarea sau ascunderea coloanelor"});