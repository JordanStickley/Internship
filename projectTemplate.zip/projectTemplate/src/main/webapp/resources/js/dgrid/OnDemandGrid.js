//>>built
define("dgrid/OnDemandGrid",["dojo/_base/declare","./Grid","./OnDemandList"],function(_1,_2,_3){return _1([_2,_3],{});});